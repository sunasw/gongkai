# Hardware ID Protection - Uninstallation Script

param(
    [switch]$Force,
    [switch]$KeepDatabase
)

$ErrorActionPreference = "Stop"
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallPath = "$env:ProgramFiles\HardwareIdProtection"
$DriverName = "HardwareIdProtectionDriver"

function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Color = "White"
    )
    Write-Host $Message -ForegroundColor $Color
}

function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Stop-Application {
    Write-ColorOutput "Stopping application..." Cyan
    
    $processes = Get-Process -Name "MainApp" -ErrorAction SilentlyContinue
    if ($processes) {
        $processes | Stop-Process -Force
        Write-ColorOutput "Application stopped." Green
    } else {
        Write-ColorOutput "Application is not running." Yellow
    }
    
    $service = Get-Service -Name "MonitorService" -ErrorAction SilentlyContinue
    if ($service) {
        Stop-Service -Name "MonitorService -Force -ErrorAction SilentlyContinue
        Write-ColorOutput "Monitor service stopped." Green
    }
    
    return $true
}

function Uninstall-Driver {
    Write-ColorOutput "Uninstalling driver..." Cyan
    
    # Stop driver service
    $service = Get-Service -Name $DriverName -ErrorAction SilentlyContinue
    if ($service) {
        Write-ColorOutput "Stopping driver service..." Yellow
        Stop-Service -Name $DriverName -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
    }
    
    # Delete driver service
    Write-ColorOutput "Removing driver service..." Yellow
    & sc delete $DriverName | Out-Null
    
    # Remove driver package using pnputil
    Write-ColorOutput "Removing driver package..." Yellow
    $driverPackages = & pnputil /enum-drivers | Select-String "HardwareIdProtectionDriver"
    
    if ($driverPackages) {
        foreach ($line in $driverPackages) {
            if ($line -match "Published Name\s+:\s+(.+)") {
                $packageName = $matches[1].Trim()
                Write-ColorOutput "Removing driver package: $packageName" Yellow
                & pnputil /delete-driver $packageName /uninstall /force | Out-Null
            }
        }
    }
    
    # Clean up registry
    Write-ColorOutput "Cleaning up registry..." Yellow
    $regPath = "HKLM:\SYSTEM\CurrentControlSet\Services\$DriverName"
    if (Test-Path $regPath) {
        Remove-Item -Path $regPath -Recurse -Force -ErrorAction SilentlyContinue
    }
    
    Write-ColorOutput "Driver uninstalled successfully." Green
    return $true
}

function Remove-DriverCertificate {
    Write-ColorOutput "Removing driver certificate..." Cyan
    
    try {
        $certPath = "$ScriptPath\Driver\$DriverName.cer"
        if (Test-Path $certPath) {
            $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($certPath)
            $store = New-Object System.Security.Cryptography.X509Certificates.X509Store("TrustedPublisher", "LocalMachine")
            $store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)
            
            $certs = $store.Certificates | Where-Object { $_.Thumbprint -eq $cert.Thumbprint }
            foreach ($c in $certs) {
                $store.Remove($c)
            }
            
            $store.Close()
            Write-ColorOutput "Certificate removed successfully." Green
        } else {
            Write-ColorOutput "Certificate file not found, skipping certificate removal." Yellow
        }
    } catch {
        Write-ColorOutput "Failed to remove certificate: $_" Yellow
    }
    
    return $true
}

function Remove-Application {
    Write-ColorOutput "Removing application..." Cyan
    
    # Remove desktop shortcut
    $shortcutPath = "$env:PUBLIC\Desktop\Hardware ID Protection.lnk"
    if (Test-Path $shortcutPath) {
        Remove-Item -Path $shortcutPath -Force
        Write-ColorOutput "Desktop shortcut removed." Green
    }
    
    # Remove start menu shortcut
    $startMenuShortcut = "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Hardware ID Protection.lnk"
    if (Test-Path $startMenuShortcut) {
        Remove-Item -Path $startMenuShortcut -Force
        Write-ColorOutput "Start menu shortcut removed." Green
    }
    
    # Remove application files
    if (Test-Path $InstallPath) {
        Write-ColorOutput "Removing application files..." Yellow
        
        if ($KeepDatabase) {
            # Backup database before deletion
            $dbPath = "$InstallPath\HardwareIdPrivacyGuard.db"
            if (Test-Path $dbPath) {
                $backupPath = "$env:TEMP\HardwareIdPrivacyGuard_Backup_$(Get-Date -Format 'yyyyMMdd_HHmmss').db"
                Copy-Item -Path $dbPath -Destination $backupPath -Force
                Write-ColorOutput "Database backed up to: $backupPath" Yellow
            }
        }
        
        Remove-Item -Path $InstallPath -Recurse -Force
        Write-ColorOutput "Application files removed." Green
    } else {
        Write-ColorOutput "Application files not found." Yellow
    }
    
    # Remove uninstall registry entries
    Write-ColorOutput "Cleaning up registry..." Yellow
    $regPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\HardwareIdProtection"
    if (Test-Path $regPath) {
        Remove-Item -Path $regPath -Recurse -Force -ErrorAction SilentlyContinue
        Write-ColorOutput "Registry entries removed." Green
    }
    
    return $true
}

function Disable-TestSigning {
    Write-ColorOutput "Checking test signing status..." Cyan
    
    $testSigning = & bcdedit /enum | Select-String "testsigning" | Select-String "Yes"
    
    if (-not $testSigning) {
        Write-ColorOutput "Test signing is not enabled." Yellow
        return $true
    }
    
    if (-not $Force) {
        $response = Read-Host "Test signing is currently enabled. Do you want to disable it? (Y/N)"
        if ($response -ne "Y" -and $response -ne "y") {
            Write-ColorOutput "Test signing will remain enabled." Yellow
            return $true
        }
    }
    
    Write-ColorOutput "Disabling test signing..." Yellow
    & bcdedit /set testsigning off | Out-Null
    
    if ($LASTEXITCODE -eq 0) {
        Write-ColorOutput "Test signing disabled successfully." Green
        Write-ColorOutput "WARNING: System reboot is required for changes to take effect." Yellow
        return $true
    } else {
        Write-ColorOutput "Failed to disable test signing." Red
        return $false
    }
}

# Main uninstallation process
function Main {
    Clear-Host
    Write-ColorOutput "========================================" Cyan
    Write-ColorOutput "Hardware ID Protection - Uninstallation" Cyan
    Write-ColorOutput "========================================" Cyan
    Write-Host ""
    
    # Check administrator privileges
    Write-ColorOutput "Checking administrator privileges..." Cyan
    if (-not (Test-Administrator)) {
        Write-ColorOutput "ERROR: This script requires administrator privileges!" Red
        Write-ColorOutput "Please right-click and select 'Run as administrator'." Yellow
        Read-Host "Press Enter to exit"
        exit 1
    }
    Write-ColorOutput "Administrator privileges confirmed." Green
    Write-Host ""
    
    # Confirm uninstallation
    if (-not $Force) {
        Write-ColorOutput "WARNING: This will remove Hardware ID Protection from your system." Yellow
        Write-ColorOutput "The following will be removed:" Yellow
        Write-Host "  - Application files"
        Write-Host "  - Driver and driver service"
        Write-Host "  - Desktop and start menu shortcuts"
        Write-Host "  - Registry entries"
        Write-Host "  - Driver certificate"
        Write-Host ""
        
        if (-not $KeepDatabase) {
            Write-ColorOutput "  - Database file (unless you use -KeepDatabase)" Red
        }
        
        Write-Host ""
        $confirm = Read-Host "Are you sure you want to continue? (Y/N)"
        if ($confirm -ne "Y" -and $confirm -ne "y") {
            Write-ColorOutput "Uninstallation cancelled." Yellow
            Read-Host "Press Enter to exit"
            exit 0
        }
    }
    
    # Stop application
    if (-not (Stop-Application)) {
        Write-ColorOutput "WARNING: Failed to stop application." Yellow
    }
    Write-Host ""
    
    # Uninstall driver
    if (-not (Uninstall-Driver)) {
        Write-ColorOutput "WARNING: Failed to uninstall driver." Yellow
    }
    Write-Host ""
    
    # Remove driver certificate
    if (-not (Remove-DriverCertificate)) {
        Write-ColorOutput "WARNING: Failed to remove driver certificate." Yellow
    }
    Write-Host ""
    
    # Remove application
    if (-not (Remove-Application)) {
        Write-ColorOutput "WARNING: Failed to remove application." Yellow
    }
    Write-Host ""
    
    # Disable test signing
    if (-not (Disable-TestSigning)) {
        Write-ColorOutput "WARNING: Failed to disable test signing." Yellow
    }
    Write-Host ""
    
    # Uninstallation complete
    Write-ColorOutput "========================================" Green
    Write-ColorOutput "Uninstallation completed successfully!" Green
    Write-ColorOutput "========================================" Green
    Write-Host ""
    Write-ColorOutput "Summary:" Cyan
    Write-Host "  - Application: Removed"
    Write-Host "  - Driver: Uninstalled"
    Write-Host "  - Certificate: Removed"
    Write-Host "  - Shortcuts: Removed"
    Write-Host "  - Registry: Cleaned"
    Write-Host ""
    
    if ($KeepDatabase) {
        Write-ColorOutput "Database was preserved as requested." Yellow
    }
    
    Write-ColorOutput "IMPORTANT NOTES:" Yellow
    Write-Host "  1. If test signing was disabled, you MUST reboot the system."
    Write-Host "  2. Some files may require a reboot to be completely removed."
    Write-Host "  3. Check the Event Viewer for any errors if issues occur."
    Write-Host ""
    
    $reboot = Read-Host "Do you want to reboot now? (Y/N)"
    if ($reboot -eq "Y" -or $reboot -eq "y") {
        Restart-Computer -Force
    }
}

# Run main function
Main
