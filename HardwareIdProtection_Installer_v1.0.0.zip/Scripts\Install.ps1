# Hardware ID Protection - Installation Script

param(
    [switch]$SkipRuntimeCheck,
    [switch]$SkipTestSigning,
    [switch]$NoDesktopShortcut
)

$ErrorActionPreference = "Stop"
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallPath = "$env:ProgramFiles\HardwareIdProtection"
$DriverName = "HardwareIdProtectionDriver"
$DriverPath = "$ScriptPath\Driver\$DriverName.sys"
$InfPath = "$ScriptPath\Driver\$DriverName.inf"
$CertPath = "$ScriptPath\Driver\$DriverName.cer"
$AppPath = "$ScriptPath\App\MainApp.exe"
$ServicePath = "$ScriptPath\App\MonitorService.exe"
$DbPath = "$ScriptPath\Database\HardwareIdPrivacyGuard.db"

function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Color = "White"
    )
    Write-Host $Message -ForegroundColor $Color
}

function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-DotNetRuntime {
    Write-ColorOutput "Checking .NET 8.0 Runtime..." Cyan
    
    try {
        $dotnetInfo = & dotnet --list-runtimes 2>$null
        if ($dotnetInfo -match "Microsoft\.NETCore\.App\s+8\.") {
            Write-ColorOutput ".NET 8.0 Runtime is installed." Green
            return $true
        }
    } catch {
        # dotnet CLI not available, check registry
    }
    
    # Check registry for installed runtimes
    $runtimePath = "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full"
    if (Test-Path $runtimePath) {
        $release = (Get-ItemProperty -Path $runtimePath -ErrorAction SilentlyContinue).Release
        if ($release -ge 528040) {
            Write-ColorOutput ".NET 8.0 Runtime is installed." Green
            return $true
        }
    }
    
    Write-ColorOutput ".NET 8.0 Runtime is NOT installed." Red
    Write-ColorOutput "Please download and install .NET 8.0 Runtime from:" Yellow
    Write-ColorOutput "https://dotnet.microsoft.com/download/dotnet/8.0" Yellow
    return $false
}

function Enable-TestSigning {
    Write-ColorOutput "Checking test signing status..." Cyan
    
    $testSigning = & bcdedit /enum | Select-String "testsigning" | Select-String "Yes"
    
    if ($testSigning) {
        Write-ColorOutput "Test signing is already enabled." Green
        return $true
    }
    
    Write-ColorOutput "Enabling test signing..." Yellow
    & bcdedit /set testsigning on | Out-Null
    
    if ($LASTEXITCODE -eq 0) {
        Write-ColorOutput "Test signing enabled successfully." Green
        Write-ColorOutput "WARNING: System reboot is required for test signing to take effect." Yellow
        return $true
    } else {
        Write-ColorOutput "Failed to enable test signing." Red
        return $false
    }
}

function Install-DriverCertificate {
    Write-ColorOutput "Installing driver certificate..." Cyan
    
    if (-not (Test-Path $CertPath)) {
        Write-ColorOutput "Certificate file not found: $CertPath" Red
        return $false
    }
    
    try {
        $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($CertPath)
        $store = New-Object System.Security.Cryptography.X509Certificates.X509Store("TrustedPublisher", "LocalMachine")
        $store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)
        $store.Add($cert)
        $store.Close()
        
        Write-ColorOutput "Certificate installed successfully." Green
        return $true
    } catch {
        Write-ColorOutput "Failed to install certificate: $_" Red
        return $false
    }
}

function Install-Driver {
    Write-ColorOutput "Installing driver..." Cyan
    
    if (-not (Test-Path $DriverPath)) {
        Write-ColorOutput "Driver file not found: $DriverPath" Red
        return $false
    }
    
    if (-not (Test-Path $InfPath)) {
        Write-ColorOutput "INF file not found: $InfPath" Red
        return $false
    }
    
    # Check if driver is already installed
    $service = Get-Service -Name $DriverName -ErrorAction SilentlyContinue
    if ($service) {
        Write-ColorOutput "Driver service already exists. Removing..." Yellow
        Stop-Service -Name $DriverName -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
        & sc delete $DriverName | Out-Null
    }
    
    # Install driver using pnputil
    $result = & pnputil /add-driver $InfPath /install
    if ($LASTEXITCODE -ne 0) {
        Write-ColorOutput "Failed to install driver using pnputil. Trying alternative method..." Yellow
        
        # Alternative: create service directly
        & sc create $DriverName binPath= $DriverPath type= kernel start= demand | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Write-ColorOutput "Driver service created successfully." Green
            return $true
        } else {
            Write-ColorOutput "Failed to create driver service." Red
            return $false
        }
    }
    
    Write-ColorOutput "Driver installed successfully." Green
    return $true
}

function Install-Application {
    Write-ColorOutput "Installing application..." Cyan
    
    # Create installation directory
    if (-not (Test-Path $InstallPath)) {
        New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
    }
    
    # Copy application files
    Write-ColorOutput "Copying application files..." Yellow
    Copy-Item -Path "$ScriptPath\App\*" -Destination $InstallPath -Recurse -Force
    
    # Copy database file
    if (Test-Path $DbPath) {
        Copy-Item -Path $DbPath -Destination $InstallPath -Force
    }
    
    # Create desktop shortcut if requested
    if (-not $NoDesktopShortcut) {
        $WshShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut("$env:PUBLIC\Desktop\Hardware ID Protection.lnk")
        $Shortcut.TargetPath = "$InstallPath\MainApp.exe"
        $Shortcut.WorkingDirectory = $InstallPath
        $Shortcut.Description = "Hardware ID Protection"
        $Shortcut.Save()
        
        Write-ColorOutput "Desktop shortcut created." Green
    }
    
    # Create uninstall shortcut
    $UninstallShortcut = $WshShell.CreateShortcut("$InstallPath\Uninstall.lnk")
    $UninstallShortcut.TargetPath = "powershell.exe"
    $UninstallShortcut.Arguments = "-ExecutionPolicy Bypass -File `"$ScriptPath\Scripts\Uninstall.ps1`""
    $UninstallShortcut.Description = "Uninstall Hardware ID Protection"
    $UninstallShortcut.Save()
    
    # Register uninstall information in registry
    $regPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\HardwareIdProtection"
    New-Item -Path $regPath -Force | Out-Null
    Set-ItemProperty -Path $regPath -Name "DisplayName" -Value "Hardware ID Protection"
    Set-ItemProperty -Path $regPath -Name "DisplayVersion" -Value "1.0.0"
    Set-ItemProperty -Path $regPath -Name "Publisher" -Value "Kiro Project"
    Set-ItemProperty -Path $regPath -Name "InstallLocation" -Value $InstallPath
    Set-ItemProperty -Path $regPath -Name "UninstallString" -Value "powershell.exe -ExecutionPolicy Bypass -File `"$ScriptPath\Scripts\Uninstall.ps1`""
    
    Write-ColorOutput "Application installed successfully." Green
    return $true
}

function Start-Application {
    Write-ColorOutput "Starting application..." Cyan
    
    try {
        Start-Process -FilePath "$InstallPath\MainApp.exe"
        Write-ColorOutput "Application started successfully." Green
        return $true
    } catch {
        Write-ColorOutput "Failed to start application: $_" Red
        return $false
    }
}

# Main installation process
function Main {
    Clear-Host
    Write-ColorOutput "========================================" Cyan
    Write-ColorOutput "Hardware ID Protection - Installation" Cyan
    Write-ColorOutput "========================================" Cyan
    Write-Host ""
    
    # Check administrator privileges
    Write-ColorOutput "Checking administrator privileges..." Cyan
    if (-not (Test-Administrator)) {
        Write-ColorOutput "ERROR: This script requires administrator privileges!" Red
        Write-ColorOutput "Please right-click and select 'Run as administrator'." Yellow
        Read-Host "Press Enter to exit"
        exit 1
    }
    Write-ColorOutput "Administrator privileges confirmed." Green
    Write-Host ""
    
    # Check .NET runtime
    if (-not $SkipRuntimeCheck) {
        if (-not (Test-DotNetRuntime)) {
            Read-Host "Press Enter to exit"
            exit 1
        }
        Write-Host ""
    }
    
    # Enable test signing
    if (-not $SkipTestSigning) {
        if (-not (Enable-TestSigning)) {
            Read-Host "Press Enter to exit"
            exit 1
        }
        Write-Host ""
    }
    
    # Install driver certificate
    if (-not (Install-DriverCertificate)) {
        Write-ColorOutput "WARNING: Certificate installation failed. Driver may not install correctly." Yellow
        Write-Host ""
    }
    
    # Install driver
    if (-not (Install-Driver)) {
        Write-ColorOutput "ERROR: Driver installation failed!" Red
        Read-Host "Press Enter to exit"
        exit 1
    }
    Write-Host ""
    
    # Install application
    if (-not (Install-Application)) {
        Write-ColorOutput "ERROR: Application installation failed!" Red
        Read-Host "Press Enter to exit"
        exit 1
    }
    Write-Host ""
    
    # Start application
    Start-Application
    Write-Host ""
    
    # Installation complete
    Write-ColorOutput "========================================" Green
    Write-ColorOutput "Installation completed successfully!" Green
    Write-ColorOutput "========================================" Green
    Write-Host ""
    Write-ColorOutput "Installation Summary:" Cyan
    Write-Host "  - Application Path: $InstallPath"
    Write-Host "  - Desktop Shortcut: Created"
    Write-Host "  - Driver: Installed"
    Write-Host "  - Certificate: Installed"
    Write-Host ""
    Write-ColorOutput "IMPORTANT NOTES:" Yellow
    Write-Host "  1. If test signing was enabled, you MUST reboot the system."
    Write-Host "  2. After reboot, the driver will be fully functional."
    Write-Host "  3. To uninstall, run Uninstall.ps1 from the Scripts folder."
    Write-Host ""
    
    $reboot = Read-Host "Do you want to reboot now? (Y/N)"
    if ($reboot -eq "Y" -or $reboot -eq "y") {
        Restart-Computer -Force
    }
}

# Run main function
Main
